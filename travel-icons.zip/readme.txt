Travel Icon Set 

License Agreement

By purchasing icons from SibCode, You (the purchaser)
agree to the terms of this agreement, as detailed below. 

You may use the icons from SibCode in commercial and
personal design projects, software or Internet products.
Icons can be displayed in documentation, help files, and
advertising materials. You are free to sell and distribute
products and projects using purchased icons without further
royalty fees. 

All icon files are provided 'as is'. SibCode cannot be
held liable for any negative issues that may occur as a
result of using the icons. 

You agree that all ownership and copyright of the icons
remains the property of SibCode. You may not resell,
distribute, lease, license or sub-license the icons or
modified icons (or a subset of the icons), to any third
party unless they are incorporated into your software or
design products. 

If you have any questions regarding copyright or licensing,
including whether another license is required for icon use
within products, please contact us here: www.sibcode.com/support.htm 

Product page:
http://www.sibcode.com/stock-icons/travel-icons.htm

Download demo:
http://www.sibcode.com/downloads/travel-icons.zip
http://www.icon-files.com/downloads/travel-icons.zip

Icon Design Service

We can design custom icons for you. Please find the basic information
about ordering icons, pricing and the portfolio here:
www.aha-soft.com/icon-design.htm


Support page: http://www.sibcode.com/support.htm

Copyright � 2000-2013 SibCode. All rights reserved. 